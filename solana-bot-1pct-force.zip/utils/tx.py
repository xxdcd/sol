import base64
from solders.transaction import VersionedTransaction
from solana.rpc.api import Client
from config.rpc import RPC_HTTP
client=Client(RPC_HTTP)
def send_raw(tx_b64,wallet):
    tx=VersionedTransaction.from_bytes(base64.b64decode(tx_b64))
    tx.sign([wallet])
    return client.send_raw_transaction(bytes(tx),opts={'skip_preflight':True,'preflight_commitment':'processed','max_retries':0}).value
