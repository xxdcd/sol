import base58
from solders.keypair import Keypair
SECRET_KEY=base58.b58decode("YOUR_PRIVATE_KEY")
WALLET=Keypair.from_bytes(SECRET_KEY)
