import time
from dex.jupiter import quote, swap_tx
from utils.tx import send_raw
from config.wallet import WALLET
from config.settings import TAKE_PROFIT, STOP_LOSS, SLIPPAGE_BPS, PRIORITY_FEE, MAX_SELL_RETRY, SELL_RETRY_DELAY

SOL = "So11111111111111111111111111111111111111112"
POSITIONS = {}

def monitor(token, amount):
    buy=POSITIONS.get(token)
    if not buy: return
    q=quote(token,SOL,amount,SLIPPAGE_BPS)
    price=q['outAmount']/q['inAmount']
    if price>=buy*TAKE_PROFIT or price<=buy*STOP_LOSS:
        force_sell(token,amount)

def force_sell(token,amount):
    for i in range(MAX_SELL_RETRY):
        try:
            q=quote(token,SOL,amount,SLIPPAGE_BPS)
            tx=swap_tx(q,WALLET.pubkey(),PRIORITY_FEE)
            send_raw(tx,WALLET)
            POSITIONS.pop(token,None)
            return
        except:
            time.sleep(SELL_RETRY_DELAY)
