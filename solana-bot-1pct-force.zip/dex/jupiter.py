import requests
JUP='https://quote-api.jup.ag/v6'
def quote(i,o,a,s):
    return requests.get(f'{JUP}/quote',params={'inputMint':i,'outputMint':o,'amount':a,'slippageBps':s}).json()['data'][0]
def swap_tx(q,u,f):
    return requests.post(f'{JUP}/swap',json={'quoteResponse':q,'userPublicKey':str(u),'wrapAndUnwrapSol':True,'computeUnitPriceMicroLamports':f}).json()['swapTransaction']
