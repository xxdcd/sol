import asyncio
from solana.rpc.websocket_api import connect
from config.rpc import RPC_WS
from dex.jupiter import quote, swap_tx
from utils.tx import send_raw
from config.wallet import WALLET
from config.settings import SNIPE_AMOUNT_SOL, SLIPPAGE_BPS, PRIORITY_FEE
from strategies.force_sell import POSITIONS

RAYDIUM_AMM = "RVKd61ztZW9L9nXxX5nGk5xG7sRKqzZo4PMBVXgS5G8"
SOL = "So11111111111111111111111111111111111111112"

async def raydium_snipe():
    async with connect(RPC_WS) as ws:
        await ws.logs_subscribe(mentions=[RAYDIUM_AMM], commitment="processed")
        print("🚀 Raydium 新池监听中")
        while True:
            msg = await ws.recv()
            logs = msg.result.value.logs
            if not logs: continue
            for l in logs:
                if "initialize2" in l:
                    token = "TOKEN_MINT"
                    q = quote(SOL, token, int(SNIPE_AMOUNT_SOL*1e9), SLIPPAGE_BPS)
                    tx = swap_tx(q, WALLET.pubkey(), PRIORITY_FEE)
                    sig = send_raw(tx, WALLET)
                    POSITIONS[token] = q["outAmount"]/q["inAmount"]
                    print("✅ 抢购成功", sig)
