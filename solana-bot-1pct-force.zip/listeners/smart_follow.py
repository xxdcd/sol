import asyncio
from solana.rpc.websocket_api import connect
from config.rpc import RPC_WS
from config.settings import SMART_WALLETS, FOLLOW_THRESHOLD
from dex.jupiter import quote, swap_tx
from utils.tx import send_raw
from config.wallet import WALLET
from strategies.force_sell import POSITIONS

SOL = "So11111111111111111111111111111111111111112"
SCORE = {}

async def smart_follow():
    async with connect(RPC_WS) as ws:
        await ws.logs_subscribe(mentions=list(SMART_WALLETS.keys()), commitment="processed")
        print("👀 聪明钱包监听中")
        while True:
            msg = await ws.recv()
            token = "TOKEN_MINT"
            SCORE[token] = SCORE.get(token,0)+1
            if SCORE[token]>=FOLLOW_THRESHOLD:
                q = quote(SOL, token, int(0.1*1e9), 800)
                tx = swap_tx(q, WALLET.pubkey(), 700_000)
                sig = send_raw(tx, WALLET)
                POSITIONS[token] = q["outAmount"]/q["inAmount"]
                print("📈 跟单买入", sig)
                SCORE[token]=0
